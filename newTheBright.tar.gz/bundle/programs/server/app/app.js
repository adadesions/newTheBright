var require = meteorInstall({"imports":{"api":{"Students.js":["meteor/mongo",function(require,exports){

/////////////////////////////////////////////////////////////////////////////
//                                                                         //
// imports/api/Students.js                                                 //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////
                                                                           //
exports.__esModule = true;                                                 //
exports.Students = undefined;                                              //
                                                                           //
var _mongo = require('meteor/mongo');                                      // 1
                                                                           //
var Students = exports.Students = new _mongo.Mongo.Collection('students');
/////////////////////////////////////////////////////////////////////////////

}]}},"server":{"main.js":["../imports/api/Students.js",function(require){

/////////////////////////////////////////////////////////////////////////////
//                                                                         //
// server/main.js                                                          //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////
                                                                           //
require('../imports/api/Students.js');                                     // 1
/////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".jsx"]});
require("./server/main.js");
//# sourceMappingURL=app.js.map
